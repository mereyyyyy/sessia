from django.urls import path
from . import views

urlpatterns = [
    path('posts/', views.PostListView.as_view(), name='post-list'),  # Барлық посттарды көрсету
    path('posts/<int:pk>/', views.PostDetailView.as_view(), name='post-detail'),  # Бір постты көрсету
    path('posts/<int:pk>/comments/', views.CommentCreateView.as_view(), name='comment-create'),  # Комментарий қосу
]